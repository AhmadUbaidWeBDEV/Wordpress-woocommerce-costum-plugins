<?php
/**
 * Plugin Name:       Koala Simple Stats
 * Plugin URI:        https://woocommerce.com/products/custom-fields-for-woocommerce/
 * Description:       This plugin Stores Simple Stats for each and every quantity of product that buyer adds to cart and also tracks the quantity of products purchased when the buyer places an order. It also keeps a product history with add history and purchase history, including details such as the buyer's username, the quantity added or purchased, and the date of addition or purchase.
 * Version:           1.1.0
 * Author:            Koala Apps
 * Developed By:      Koala Apps
 * Author URI:        https://woocommerce.com/vendor/Koalaapps/
 * Support:           https://woocommerce.com/vendor/Koalaapps/
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       koala_s_s
 * Woo:               8590204:3320a451b314c29dc2a22e8ac624d8cf
 * WC requires at least: 3.0.9
 * WC tested up to: 7.*.*
 *
 * @package koala_s_s
 */

if ( ! defined( 'ABSPATH' ) ) {
	die;
}

if ( ! defined( 'WPINC' ) ) {
	die;
}

if ( ! class_exists( 'Ka_Wss_Simple_Stats_Main' ) ) {
	/**
	 * Class Ka_Wss_Simple_Stats_Main
	 */
	class Ka_Wss_Simple_Stats_Main {

		/**
		 * Class constructor.
		 */
		public function __construct() {

			$this->constant_define();
			add_action( 'after_setup_theme', array( $this, 'afreg_init' ) );
			register_activation_hook( __FILE__, array( $this, 'afreg_installation' ) );
			require_once KA_S_S_PLUGIN_DIR . 'includes/admin/class-ka-wss-simple-stats-admin.php';
			require_once KA_S_S_PLUGIN_DIR . 'includes/front/class-ka-wss-simple-stats-front.php';

		}
		/**
		 * Constant_define().
		 */
		public function constant_define() {

			if ( ! defined( 'KA_S_S_PLUGIN_URL' ) ) {
				 define( 'KA_S_S_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
			}

			if ( ! defined( 'KA_S_S_PLUGIN_DIR' ) ) {
				define( 'KA_S_S_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
			}
		}
		/**
		 * Perform actions on plugin installation.
		 */
		public function afreg_installation() {
			// Update options on plugin installation.
		}
		/**
		 * Initialize the plugin.
		 */
		public function afreg_init() {
			if ( function_exists( 'load_plugin_textdomain' ) ) {
				load_plugin_textdomain( 'koala_s_s', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
			}
		}
	}

	new Ka_Wss_Simple_Stats_Main();
}

