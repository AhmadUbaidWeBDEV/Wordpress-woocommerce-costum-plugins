jQuery(document).ready(function($){


    $('.multiple_product_select').select2();});


function toggleResetTimeOption(){
	
    var enableAutoReset = document.getElementById("wsss_enable_auto_reset").checked;
    var nextResetTimeOption = document.getElementById("resettoggle");

    if (enableAutoReset) {
        nextResetTimeOption.style.display = "block";
    } else {
        nextResetTimeOption.style.display = "none";
    }
 }