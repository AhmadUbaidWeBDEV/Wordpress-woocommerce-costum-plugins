<?php
/**
 * File containing the Ka_Wss_Simple_Stats_Front class.
 *
 * @package koala_s_s
 */
if ( ! defined( 'ABSPATH' ) ) {
	die;
}
/**
 * Class Ka_Wss_Simple_Stats_Front
 */
class Ka_Wss_Simple_Stats_Front {

	/**
	 * Class constructor.
	 */
	public function __construct() {
		add_action( 'woocommerce_add_to_cart', array( $this, 'k_a_save_added_quantity_on_add_to_cart' ), 10, 6 );
		add_filter( 'woocommerce_update_cart_validation', array( $this, 'k_a_update_cart' ), 10, 4 );
		add_action( 'woocommerce_checkout_order_processed', array( $this, 'k_a_save_purchase_quantity_on_place_order' ), 10, 1 );
		// add_action('wp_loaded', array($this,'check_ss')).
	}

	/**
	 * Save added quantity on add to cart.
	 *
	 * @param string $cart_item_key   Cart item key.
	 * @param int    $product_id      Product ID.
	 * @param int    $quantity        Quantity.
	 * @param int    $variation_id    Variation ID.
	 * @param array  $variation       Variation data.
	 * @param array  $cart_item_data  Cart item data.
	 */
	public function k_a_save_added_quantity_on_add_to_cart( $cart_item_key, $product_id, $quantity, $variation_id, $variation, $cart_item_data ) {
		$current_user     = wp_get_current_user();
		$current_username = $current_user->user_login;
		$sales_detail     = (array) get_post_meta( $product_id, 'ka_save_add_quantity', true );
		$sales_detail[]   = array(
			'username' => $current_username,
			'quantity' => $quantity,
			'user_id'  => get_current_user_id(),
			'Date'     => gmdate( 'Y-m-d' ),
		);

		update_post_meta( $product_id, 'ka_save_add_quantity', $sales_detail );
	}

	/**
	 * Update cart.
	 *
	 * @param bool   $passed              Validation status.
	 * @param string $cart_item_key       Cart item key.
	 * @param array  $values              Cart item values.
	 * @param int    $cart_change_quantity Cart change quantity.
	 * @return bool Updated validation status.
	 */
	public function k_a_update_cart( $passed, $cart_item_key, $values, $cart_change_quantity ) {
		$current_user     = wp_get_current_user();
		$current_username = $current_user->user_login;

		foreach ( WC()->cart->get_cart() as $cartkey => $cart_item ) {
			if ( $cartkey === $cart_item_key ) {
				if ( $cart_item['quantity'] < $cart_change_quantity ) {
					$updated_quantity = $cart_change_quantity - $cart_item['quantity'];
					$sales_detail     = (array) get_post_meta( $cart_item['product_id'], 'ka_save_add_quantity', true );
					$sales_detail[]   = array(
						'username' => $current_username,
						'quantity' => $updated_quantity,
						'user_id'  => get_current_user_id(),
						'Date'     => gmdate( 'Y-m-d' ),
					);
					update_post_meta( $cart_item['product_id'], 'ka_save_add_quantity', $sales_detail );
				}
			}
		}

		return $passed;
	}

	/**
	 * Save purchase quantity on place order.
	 *
	 * @param int $order_id Order ID.
	 */
	public function k_a_save_purchase_quantity_on_place_order( $order_id ) {
		$current_user     = wp_get_current_user();
		$current_username = $current_user->user_login;
		$order            = wc_get_order( $order_id );
		foreach ( $order->get_items() as $item_id => $item ) {
			$product_id     = $item->get_product_id();
			$product_name   = $item->get_name();
			$quantity       = $item->get_quantity();
			$sales_detail   = (array) get_post_meta( $product_id, 'ka_save_purchase_quantity', true );
			$sales_detail[] = array(
				'username'   => $current_username,
				'user_id'    => get_current_user_id(),
				'Product_id' => $product_id,
				'Quantity'   => $quantity,
				'order_id'   => $order_id,
				'item_id'    => $item_id,
				'Date'       => gmdate( 'Y-m-d' ),
			);
			update_post_meta( $product_id, 'ka_save_purchase_quantity', $sales_detail );
		}
	}

	// end check_ss().
}

new Ka_Wss_Simple_Stats_Front();

