<?php
/**
 * File containing the Ka_Wss_Simple_Stats_Front class.
 *
 * @package koala_s_s
 */
if ( ! defined( 'ABSPATH' ) ) {
	die;
}
/**
 * Class Ka_Wss_Simple_Stats_Admin
 */
class Ka_Wss_Simple_Stats_Admin {
	/**
	 * Construct().
	 */
	public function __construct() {
		add_action( 'init', array( $this, 'init' ) );
		add_filter( 'manage_edit-product_columns', array( $this, 'add_custom_columns_to_product_table' ) );
		add_action( 'manage_product_posts_custom_column', array( $this, 'populate_custom_columns_in_product_table' ) );
		add_filter( 'woocommerce_product_data_tabs', array( $this, 'add_product_history_tab' ) );
		add_action( 'woocommerce_product_data_panels', array( $this, 'product_history_tab_content' ) );
		add_filter( 'woocommerce_settings_tabs_array', array( $this, 'add_settings_tab' ), 50 );
		add_action( 'woocommerce_settings_tabs_wsss_settings', array( $this, 'display_settings_content' ) );
		add_action( 'woocommerce_update_options_wsss_settings', array( $this, 'save_settings' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'ka_enqueue_scripts' ) );

	}
	/**
	 * Add_custom_columns_to_product_table.
	 *
	 * @param array $columns return colums.
	 */
	public function add_custom_columns_to_product_table( $columns ) {
		$new_columns = array();

		foreach ( $columns as $column_key => $column_name ) {
			$new_columns[ $column_key ] = $column_name;

			if ( 'date' == $column_key ) {
				$new_columns['adds'] = __( 'Adds', 'woocommerce' );
				$new_columns['buys'] = __( 'Buys', 'woocommerce' );
			}
		}

		return $new_columns;
	}
	/**
	 * Add_product_history_tab.
	 *
	 * @param array $tabs return tabs.
	 */
	public function add_product_history_tab( $tabs ) {
		global $post;
		$product = wc_get_product( $post->ID );
		if ( $product ) {
			switch ( $product->get_type() ) {
				case 'simple':
					$tabs['product_history'] = array(
						'label'  => __( 'Product History', 'text-domain' ),
						'target' => 'product_history_data',
						'class'  => array( 'show_if_simple' ),
					);
					break;
				case 'variable':
					$tabs['product_history'] = array(
						'label'  => __( 'Product History', 'text-domain' ),
						'target' => 'product_history_data',
						'class'  => array( 'show_if_variable' ),
					);
					break;
				case 'grouped':
					$tabs['product_history'] = array(
						'label'  => __( 'Product History', 'text-domain' ),
						'target' => 'product_history_data',
						'class'  => array( 'show_if_grouped' ),
					);
					break;
				case 'external':
					$tabs['product_history'] = array(
						'label'  => __( 'Product History', 'text-domain' ),
						'target' => 'product_history_data',
						'class'  => array( 'show_if_external' ),
					);
					break;
				default:
					// Handle other product types if needed
					break;
			}
		}
		return $tabs;
	}
	/**
	 * Populate_custom_columns_in_product_table.
	 *
	 * @param array $column return colums.
	 */
	public function populate_custom_columns_in_product_table( $column ) {
		global $post;

		if ( 'adds' == $column ) {
			$add_detail = (array) get_post_meta( $post->ID, 'ka_save_add_quantity', true );
			$quantity   = 0;
			foreach ( $add_detail as $arrdata ) {

				if ( isset( $arrdata['quantity'] ) ) {

					$quantity += $arrdata['quantity'];

				}
			}
			echo esc_html( $quantity );
		}

		if ( 'buys' == $column ) {
			$buy_detail = (array) get_post_meta( $post->ID, 'ka_save_purchase_quantity', true );
			$quantity   = 0;
			foreach ( $buy_detail as $buyarrdata ) {
				if ( isset( $buyarrdata['Quantity'] ) ) {

					$quantity += $buyarrdata['Quantity'];

				}
			}

			echo esc_html( $quantity );
		}
	}
	/**
	 * Product_history_tab_content .
	 */
	public function product_history_tab_content() {
		global $post, $product;
		$product_id = $post->ID;
		echo '<div id="product_history_data" class="panel woocommerce_options_panel">';
		echo '<div class="tabflex">';
		echo '<div class="add-history">';
		echo '<h3 class="addheading">Product Add History</h3>';
		$add_detail = (array) get_post_meta( $product_id, 'ka_save_add_quantity', true );
		if ( is_array( $add_detail ) ) {
			echo '<table class="woocommerce_options_panel woocommerce_meta_box_data">';
			echo '<thead><tr><th>User Name</th><th>Quantity</th><th>Date</th></tr></thead>';
			$elements_in_array = count( $add_detail );
			if ( $elements_in_array > 0 ) {
				for ( $i = 0; $i < $elements_in_array; $i++ ) {
					echo '<tr>';
					$current_element_in_array = $add_detail[ $i ];
					foreach ( $current_element_in_array as $key => $value ) {
						if ( 'user_id' === $key ) {
							continue;
						}
						echo '<td>' . esc_html( $value ) . '</td>';
					}
					echo '</tr>';
				}
			} else {
				echo '<tr><td colspan="3">No add history available.</td></tr>';
			}
			echo '</table>';
		} else {
			echo '<p>No add history available.</p>';
		}
		echo '</div>';
		echo '<div class="add-history" >';
		echo '<h3 class="addheading" >Product Purchase History</h3>';
		$buy_detail = (array) get_post_meta( $product_id, 'ka_save_purchase_quantity', true );
		if ( is_array( $buy_detail ) ) {
			echo '<table class="woocommerce_options_panel woocommerce_meta_box_data">';
			echo '<thead><tr><th>User Name</th><th>Quantity</th><th>Date</th></tr></thead>';
			$elements_in_array = count( $buy_detail );
			if ( $elements_in_array > 0 ) {
				for ( $i = 0; $i < $elements_in_array; $i++ ) {
					echo '<tr>';
					$current_element_in_array = $buy_detail[ $i ];
					foreach ( $current_element_in_array as $key => $value ) {
						if ( 'user_id' === $key || 'Product_id' === $key || 'item_id' === $key || 'order_id' === $key ) {
							continue;
						}
						if ( ( $buy_detail[ $i ]['Quantity'] ) != 0 ) {
							echo '<td>' . esc_html( $value ) . '</td>';
						}
					}
					echo '</tr>';
				}
			} else {
				echo '<tr><td colspan="3">No Purchase available.</td></tr>';
			}
			echo '</table>';
		} else {
			echo '<p>No Purchase available.</p>';
		}

		echo '</div>';
		echo '</div>';
		echo '</div>';
	}
	/**
	 * Add_settings_tab
	 *
	 * @param array $tabs return tabs .
	 */
	public function add_settings_tab( $tabs ) {
		$tabs['wsss_settings'] = 'Simple Stats Settings';
		return $tabs;
	}
	 /**
	  * Display_settings_content()
	  */
	public function display_settings_content() {
		$enable_auto_reset                = get_option( 'wsss_enable_auto_reset' );
		$wsss_enable_single_auto_reset    = get_option( 'wsss_enable_single_auto_reset' );
		$wsss_enable_refundcal_auto_reset = get_option( 'wsss_enable_refundcal_auto_reset' );
		$wsss_refunds_calculation_time    = get_option( 'wsss_refunds_calculation_time' );
		$wsss_refunds_calculation_unit    = get_option( 'wsss_refunds_calculation_unit' );
		?>
<div class="wrap woocommerce">
	<h1><?php esc_html_e( 'Simple Stats Settings', 'woocommerce' ); ?></h1>
	
	<!-- Enable auto reset setting -->
	
		<!-- Enable single product reset setting -->
		<table class="form-table">
			<tr valign="top">
				<th scope="row"><?php esc_html_e( 'Reset product type', 'woocommerce' ); ?></th>
				<td>
					<label for="wsss_enable_single_auto_reset">
						<select name="wsss_enable_single_auto_reset[]" class="multiple_product_select" id="wsss_enable_single_auto_reset" multiple>
							<?php
							$product_types = get_terms( 'product_type', array( 'hide_empty' => false ) );

							if ( $product_types && ! is_wp_error( $product_types ) ) {
								foreach ( $product_types as $product_type ) {
									?>
								<option value="<?php echo esc_attr( $product_type->name ); ?>" <?php selected( true, in_array( $product_type->name, (array) $wsss_enable_single_auto_reset ) ); ?>><?php echo esc_html( $product_type->name ); ?></option>

									<?php
								}
							}
							?>
						</select>
					</label>
					<p class="description">
						<?php esc_html_e( 'Select the product types for which the "Reset Counters" action link should be displayed in the product table.', 'woocommerce' ); ?>
					</p>
				</td>
			</tr>
		</table>

	<!-- Enable refunds calculation setting -->
	<table class="form-table">
		<tr valign="top">
			<th scope="row"><?php esc_html_e( 'Enable refunds calculation:', 'woocommerce' ); ?></th>
			<td> 
				<label for="wsss_enable_refundcal_auto_reset">
					<input type="checkbox" name="wsss_enable_refundcal_auto_reset" id="wsss_enable_refundcal_auto_reset" value="yes" <?php checked( $wsss_enable_refundcal_auto_reset, 'yes' ); ?>>
					<?php esc_html_e( 'YES', 'woocommerce' ); ?>
				</label>
				<p class="description">
					<?php esc_html_e( 'If enabled, when an order is refunded, the sales counter will be decremented by the quantity of the returned product.', 'your-domain' ); ?>
				</p>
			</td>
		</tr>
	</table>

	<table class="form-table">
		<tr valign="top">
			<th scope="row"><?php esc_html_e( 'Enable reset:', 'woocommerce' ); ?></th>
			<td>
				<label for="wsss_enable_auto_reset">
					<input type="checkbox" name="wsss_enable_auto_reset" id="wsss_enable_auto_reset" onchange="toggleResetTimeOption()" value="yes" <?php checked( $enable_auto_reset, 'yes' ); ?>>
					<?php esc_html_e( 'YES', 'your-domain' ); ?>
				</label>
				<p class="description">
					<?php esc_html_e( 'If enabled, counters will automatically reset after a period of time set under the Auto reset frequency', 'your-domain' ); ?>
				</p>
			</td>
		</tr>
	</table>
	<!-- Refunds calculation date and time setting -->
	<table class="form-table" id="resettoggle" style="display:none;">
		<tr valign="top">
			<th scope="row"><?php esc_html_e( 'Auto Reset time:', 'your-domain' ); ?></th>
			<td> 
				<input   type="number" min="0" id="wsss_refunds_calculation_time" name="wsss_refunds_calculation_time" value="<?php echo esc_attr( $wsss_refunds_calculation_time ); ?>">
				<select id="timecalculte" name="wsss_refunds_calculation_unit">
					<option value="hours" <?php selected( 'hours', $wsss_refunds_calculation_unit ); ?>>hours</option>
					<option value="minutes" <?php selected( 'minutes', $wsss_refunds_calculation_unit ); ?>>minutes</option>
					<option value="seconds" <?php selected( 'seconds', $wsss_refunds_calculation_unit ); ?>>seconds</option>
					<option value="days" <?php selected( 'days', $wsss_refunds_calculation_unit ); ?>>days</option>              
				</select>
				<p class="description">
					<?php esc_html_e( 'Specifies the period (in days) after which the counters will be reset. Works only if Enable auto reset is checked', 'your-domain' ); ?>
				</p>
				
			</td>
		</tr>
	</table>
	
</div>
		<?php
	}
	/**
	 * Save_settings()
	 */
	public function save_settings() {

		$enable_auto_reset = isset( $_POST['wsss_enable_auto_reset'] ) ? 'yes' : 'no';
		wp_clear_scheduled_hook( 'ka_costum_cron_hook_simple_stats' );
		update_option( 'wsss_enable_auto_reset', $enable_auto_reset );

		$wsss_enable_single_auto_reset = isset( $_POST['wsss_enable_single_auto_reset'] ) ? (array) array_map( 'sanitize_text_field', wp_unslash( $_POST['wsss_enable_single_auto_reset'] ) ) : array();
		update_option( 'wsss_enable_single_auto_reset', $wsss_enable_single_auto_reset );

		$wsss_enable_refundcal_auto_reset = isset( $_POST['wsss_enable_refundcal_auto_reset'] ) ? 'yes' : 'no';
		update_option( 'wsss_enable_refundcal_auto_reset', $wsss_enable_refundcal_auto_reset );

		$wsss_refunds_calculation_time = isset( $_POST['wsss_refunds_calculation_time'] ) ? intval( $_POST['wsss_refunds_calculation_time'] ) : 0;
		update_option( 'wsss_refunds_calculation_time', $wsss_refunds_calculation_time );

		$wsss_refunds_calculation_unit = isset( $_POST['wsss_refunds_calculation_unit'] ) ? sanitize_text_field( wp_unslash( $_POST['wsss_refunds_calculation_unit'] ) ) : 'hours';
		update_option( 'wsss_refunds_calculation_unit', $wsss_refunds_calculation_unit );

		if ( ! isset( $_POST['_wpnonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ), 'wsss_settings_nonce' ) ) {
			// Nonce verification failed. Handle the error or return an appropriate response.
			return;
		}
	}
	/**
	 * Init()
	 */
	public function init() {
		$enable_auto_reset = get_option( 'wsss_enable_auto_reset' );

		if ( 'yes' == $enable_auto_reset ) {
			add_filter( 'cron_schedules', array( $this, 'simple_stats_cron_schedule' ) );

			if ( ! wp_next_scheduled( 'ka_costum_cron_hook_simple_stats' ) ) {
				wp_schedule_event( time(), 'simple_stats_cron_interval', 'ka_costum_cron_hook_simple_stats' );

			}
			add_action( 'ka_costum_cron_hook_simple_stats', array( $this, 'cron_callback' ) );
		}

		$wsss_enable_refundcal_auto_reset = get_option( 'wsss_enable_refundcal_auto_reset' );
		if ( 'yes' == $wsss_enable_refundcal_auto_reset ) {
			add_action( 'woocommerce_order_refunded', array( $this, 'refund_calculation_simple_stats' ), 10, 2 );
		}
	}
	 /**
	  * Hour_min_second_schedule
	  *
	  * @param array $schedules return time interval.
	  */
	public function simple_stats_cron_schedule( $schedules ) {
		$wsss_refunds_calculation_unit = get_option( 'wsss_refunds_calculation_unit' );
		$wsss_refunds_calculation_time = get_option( 'wsss_refunds_calculation_time' );
		switch ( $wsss_refunds_calculation_unit ) {
			case 'minutes':
				$schedules['simple_stats_cron_interval'] = array(
					'interval' => $wsss_refunds_calculation_time * 60,
				);
				break;
			case 'seconds':
				$schedules['simple_stats_cron_interval'] = array(
					'interval' => $wsss_refunds_calculation_time,
				);
				break;
			case 'days':
				$schedules['simple_stats_cron_interval'] = array(
					'interval' => $wsss_refunds_calculation_time * 86400,
				);
				break;
			default:
				$schedules['simple_stats_cron_interval'] = array(
					'interval' => $wsss_refunds_calculation_time * 3600,
				);
				break;
		}

		return $schedules;
	}
	 /**
	  * Cron_callback()
	  */
	public function cron_callback() {

		$product_types = get_option( 'wsss_enable_single_auto_reset' );
		$args          = array(
			'limit' => -1,  // Retrieve all products.
			'type'  => $product_types, // Filter by selected product types.
		);
		$product_query = new WC_Product_Query( $args );
		$products      = $product_query->get_products();
		foreach ( $products as $product ) {
			update_post_meta( $product->get_id(), 'ka_save_add_quantity', array() );
			update_post_meta( $product->get_id(), 'ka_save_purchase_quantity', array() );
		}

	}
	 /**
	  * Get_refund_product_id_and_quantity
	  *
	  * @param int $order_id The ID of the order.
	  * @param int $refund_id The ID of the refund.
	  */
	public function refund_calculation_simple_stats( $order_id, $refund_id ) {
		$refund         = wc_get_order( $refund_id );
		$refunded_items = $refund->get_items();

		foreach ( $refunded_items as $item_id => $item ) {

			$product_id        = $item->get_product_id();
			$refunded_quantity = $item->get_quantity();

			$purchase_detail = (array) get_post_meta( $product_id, 'ka_save_purchase_quantity', true );
			$j               = count( $purchase_detail );
			for ( $i = 0; $i < $j; $i++ ) {
				$item_id_from_sales = isset( $purchase_detail[ $i ]['item_id'] ) ? $purchase_detail[ $i ]['item_id'] : '';
				if ( $item->get_meta( '_refunded_item_id' ) == $item_id_from_sales ) {
					$purchase_detail[ $i ]['Quantity'] = $refunded_quantity + $purchase_detail[ $i ]['Quantity'];
					if ( $purchase_detail[ $i ]['Quantity'] >= 0 ) {
						update_post_meta( $product_id, 'ka_save_purchase_quantity', $purchase_detail );
					}
					break;
				}
			}
		}
	}
	/**
	 * Ka_enqueue_scripts
	 */
	public function ka_enqueue_scripts() {

		wp_enqueue_style( 'my_custom_css', KA_S_S_PLUGIN_URL . '/assets/css/admin.css', array(), '1.0.0', 'all' );
		wp_enqueue_style( 'select2-css', plugins_url( 'assets/css/select2.css', WC_PLUGIN_FILE ), array(), '5.7.2' );
		wp_enqueue_script( 'select2-js', plugins_url( 'assets/js/select2/select2.min.js', WC_PLUGIN_FILE ), array( 'jquery' ), '4.0.3', true );
		wp_enqueue_script( 'my_custom_js', KA_S_S_PLUGIN_URL . '/assets/js/admin.js', array( 'jquery' ), '1.0.0', false );
		wp_localize_script( 'my_custom_js', 'my_script_data', array( 'ajax_url' => admin_url( 'admin-ajax.php' ) ) );
	}


}



new Ka_Wss_Simple_Stats_Admin();


?>
